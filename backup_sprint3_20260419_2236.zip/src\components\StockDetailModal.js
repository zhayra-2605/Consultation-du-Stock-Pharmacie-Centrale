import React from 'react';

const getDatePeremption = (item) => {
  const date = item.DATEPEREMP ?? item.DATE_PEREMPTION ?? item.date_peremption ?? '';
  if (!date || date === '0000-00-00' || String(date).startsWith('0000-00-00')) {
    return '-';
  }
  return date;
};

const StockDetailModal = ({ isOpen, onClose, data, depotName, productInfo }) => {
  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content-custom" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header-custom">
          <h4>Stock Dépôt</h4>
          <button onClick={onClose} className="btn-close-custom" aria-label="Fermer">×</button>
        </div>

        <div className="modal-body-custom">
          <div className="table-responsive" style={{ maxHeight: '70vh', overflowY: 'auto' }}>
            <table className="table-custom">
              <thead>
                <tr>
                  <th>Code Produit</th>
                  <th>Libellé</th>
                  <th>Dépôt</th>
                  <th>Num lot</th>
                  <th>Date péremption</th>
                  <th>Stock</th>
                  <th>Qte bloquée</th>
                  <th>Quarantaine</th>
                  <th>Stock total</th>
                  <th>Vente total</th>
                </tr>
              </thead>
              <tbody>
                {data && data.length > 0 ? (
                  data.map((item, index) => (
                    <tr key={item.ID ?? index}>
                      <td>{item.CODE_PRODUIT ?? item.CODE_PRODUIT}</td>
                      <td>{item.LIBELLE_PRODUIT ?? item.LIBELLE ?? productInfo?.libelle}</td>
                      <td>{item.LIBELLE_DEPOT}</td>
                      <td>{item.NUM_LOT ?? item.NUMLOT ?? '-'}</td>
                      <td>{getDatePeremption(item)}</td>
                      <td>{item.STOCK ?? item.STOCK_PHYSIQUE ?? item.QUANTITET ?? item.STOCK_TOTAL}</td>
                      <td>{item.QTE_BLOQUEE ?? item.QTEBLK ?? 0}</td>
                      <td>{item.QUARANTAINE ?? 0}</td>
                      <td style={{ fontWeight: 'bold' }}>{item.STOCK_TOTAL ?? 0}</td>
                      <td>{item.VENTE_TOTAL ?? 0}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={10} style={{ padding: 0, border: 'none' }}>
                      <div style={{
                        backgroundColor: '#fff1f2',
                        border: '1px solid #fca5a5',
                        borderRadius: '8px',
                        padding: '20px 24px',
                        margin: '12px 8px',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '12px',
                        color: '#b91c1c',
                        fontWeight: '600',
                        fontSize: '0.95rem'
                      }}>
                        <span style={{ fontSize: '1.4rem' }}>🚫</span>
                        Aucun détail de stock disponible pour ce dépôt.
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StockDetailModal;
