import React from 'react';

const MetricGauges = ({ data }) => {
  const { adequacy = 68, stockouts = 14, gaps = 8 } = data || {};

  const Gauge = ({ label, value, color, unit }) => (
    <div className="gauge-card">
      <div className="gauge-label">{label}</div>
      <div className="gauge-inner">
        <div className="gauge-value" style={{ color }}>{value}</div>
        <div className="gauge-unit">{unit}</div>
      </div>
      <div className="gauge-progress-bg">
        <div 
          className="gauge-progress-bar" 
          style={{ 
            width: `${Math.min(value, 100)}%`, 
            backgroundColor: color,
            boxShadow: `0 0 10px ${color}88`
          }} 
        />
      </div>
    </div>
  );

  return (
    <div className="gauges-container">
      <Gauge 
        label="Adéquation Stock Global" 
        value={adequacy} 
        unit="%" 
        color="var(--bio-green-primary)" 
      />
      <Gauge 
        label="Ruptures Actives (Régions)" 
        value={stockouts} 
        unit="Régions" 
        color="var(--danger-red)" 
      />
      <Gauge 
        label="Écarts Prédictifs (Besoins)" 
        value={gaps} 
        unit="Besoins" 
        color="#f59e0b" 
      />

      <style jsx>{`
        .gauges-container {
          display: flex;
          gap: 20px;
          margin-bottom: 24px;
        }
        .gauge-card {
          flex: 1;
          background: var(--glass-white);
          backdrop-filter: blur(24px);
          border-radius: var(--radius-glass-card);
          padding: 20px;
          border: 1px solid var(--glass-border);
          box-shadow: var(--shadow-glass);
          display: flex;
          flex-direction: column;
          gap: 12px;
        }
        .gauge-label {
          font-size: 0.85rem;
          font-weight: 800;
          text-transform: uppercase;
          color: var(--text-secondary);
          letter-spacing: 0.05em;
        }
        .gauge-inner {
          display: flex;
          align-items: baseline;
          gap: 6px;
        }
        .gauge-value {
          font-size: 2.2rem;
          font-weight: 900;
        }
        .gauge-unit {
          font-size: 0.9rem;
          font-weight: 700;
          color: var(--text-muted);
        }
        .gauge-progress-bg {
          height: 8px;
          background: rgba(0,0,0,0.05);
          border-radius: 4px;
          overflow: hidden;
        }
        .gauge-progress-bar {
          height: 100%;
          transition: width 1s ease-out;
        }
      `}</style>
    </div>
  );
};

export default MetricGauges;
