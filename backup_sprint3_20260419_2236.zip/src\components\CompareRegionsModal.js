import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { REGIONS } from '../constants/regions';

import { getCodeBesoin, getCodeProduit } from '../utils/dataUtils';
import { generateComparisonReport } from '../utils/pdfGenerator';

const CompareRegionsModal = ({ isOpen, onClose, selectedProduct, isBesoinSearch }) => {
    const [region1, setRegion1] = useState('Tunis');
    const [region2, setRegion2] = useState('Medenine');
    const [op, setOp] = useState('<=');
    const [val, setVal] = useState(2);

    const [historyMonths, setHistoryMonths] = useState(6);
    const [loading, setLoading] = useState(false);
    const [results, setResults] = useState([]);

    useEffect(() => {
        if (isOpen && selectedProduct) {
            handleApply();
        }
    }, [isOpen, selectedProduct]);

    const handleApply = async () => {
        if (!selectedProduct) return;
        setLoading(true);
        try {
            const code = isBesoinSearch ? getCodeBesoin(selectedProduct) : getCodeProduit(selectedProduct);
            const res = await api.compareRegionsAdvanced({
                code,
                isBesoin: isBesoinSearch,
                region1, op1: op, val1: val,
                region2, op2: op, val2: val,
                historyMonths
            });
            setResults(res.data || []);
        } catch (error) {
            console.error("Error fetching advanced comparison data", error);
        } finally {
            setLoading(false);
        }
    };

    const handleReset = () => {
        setRegion1('Tunis');
        setRegion2('Medenine');
        setOp('<=');
        setVal(2);
        setHistoryMonths(6);
        setResults([]);
    };

    if (!isOpen) return null;

    return (
        <div className="modal-overlay" onClick={onClose}>
            <div className="modal-content-custom" onClick={e => e.stopPropagation()} style={{ width: '1200px', maxWidth: '95vw' }}>
                <div className="modal-header-custom">
                    <h4>Comparaison Avancée de Régions</h4>
                    <button className="btn-close-custom" onClick={onClose}>×</button>
                </div>
                
                <div className="modal-body-custom">
                    {!selectedProduct ? (
                        <div className="alert alert-warning">
                            Veuillez sélectionner un produit ou un besoin.
                        </div>
                    ) : (
                        <>
                            {/* Zone de Filtres avec Design Premium */}
                            <div style={{ padding: '24px', marginBottom: '32px', background: 'rgba(255, 255, 255, 0.7)', borderRadius: '24px',backdropFilter: 'blur(10px)', border: '1px solid rgba(255,255,255,0.8)', boxShadow: '0 8px 32px rgba(0,0,0,0.04)' }}>
                                <div style={{ display: 'grid', gridTemplateColumns: '1fr auto 1fr', gap: '24px', alignItems: 'center' }}>
                                    
                                    {/* Region 1 Card */}
                                    <div style={{ padding: '24px', background: 'linear-gradient(145deg, #ffffff, #f8f9fc)', borderRadius: '16px', boxShadow: '0 10px 20px -5px rgba(0,0,0,0.05)', border: '1px solid #e2e8f0', textAlign: 'center' }}>
                                        <div className="mb-0">
                                            <label style={{ color: '#4f46e5', fontWeight: '800', fontSize: '1.2rem', marginBottom: '16px', display: 'block' }}>📍 Région 1</label>
                                            <select className="form-select mx-auto" style={{ border: '2px solid #eef2ff', borderRadius: '8px', padding: '12px 20px', fontWeight: '700', color: '#1e293b', maxWidth: '250px', display: 'block' }} value={region1} onChange={e => setRegion1(e.target.value)}>
                                                {REGIONS.filter(r => r !== 'National').map(r => <option key={r} value={r}>{r}</option>)}
                                            </select>
                                        </div>
                                    </div>

                                    {/* VS Badge */}
                                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                                        <div style={{ 
                                            width: '56px', height: '56px', borderRadius: '50%', 
                                            background: 'linear-gradient(135deg, #4f46e5, #008e54)', 
                                            color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', 
                                            fontWeight: '900', fontSize: '1.2rem', fontStyle: 'italic',
                                            boxShadow: '0 8px 16px rgba(79, 70, 229, 0.3)', border: '4px solid #ffffff', zIndex: 10 
                                        }}>VS</div>
                                    </div>

                                    {/* Region 2 Card */}
                                    <div style={{ padding: '24px', background: 'linear-gradient(145deg, #ffffff, #f8f9fc)', borderRadius: '16px', boxShadow: '0 10px 20px -5px rgba(0,0,0,0.05)', border: '1px solid #e2e8f0', textAlign: 'center' }}>
                                        <div className="mb-0">
                                            <label style={{ color: '#008e54', fontWeight: '800', fontSize: '1.2rem', marginBottom: '16px', display: 'block' }}>📍 Région 2</label>
                                            <select className="form-select mx-auto" style={{ border: '2px solid #ecfdf5', borderRadius: '8px', padding: '12px 20px', fontWeight: '700', color: '#1e293b', maxWidth: '250px', display: 'block' }} value={region2} onChange={e => setRegion2(e.target.value)}>
                                                {REGIONS.filter(r => r !== 'National').map(r => <option key={r} value={r}>{r}</option>)}
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                {/* Ligne de contrôle d'exécution GLOBALE */}
                                <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', gap: '16px', marginTop: '32px', alignItems: 'center', background: '#f8fafc', padding: '16px 24px', borderRadius: '12px', border: '1px dashed #cbd5e1' }}>
                                    
                                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                                        <i className="fas fa-history text-muted"></i>
                                        <span style={{ fontSize: '0.95rem', fontWeight: '600', color: '#334155' }}>Moyenne Mensuelle sur :</span>
                                        <select className="form-select" style={{ width: '130px', fontWeight: 'bold', border: '1px solid #cbd5e1' }} value={historyMonths} onChange={e => setHistoryMonths(e.target.value)}>
                                            <option value="3">3 mois</option>
                                            <option value="6">6 mois</option>
                                            <option value="12">12 mois</option>
                                        </select>
                                    </div>

                                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', borderLeft: '1px solid #cbd5e1', paddingLeft: '16px' }}>
                                        <i className="fas fa-filter text-muted"></i>
                                        <span style={{ fontSize: '0.95rem', fontWeight: '600', color: '#334155' }}>Filtrer Couverture :</span>
                                        <select className="form-select" style={{ width: '80px', fontWeight: 'bold', border: '1px solid #cbd5e1' }} value={op} onChange={e => setOp(e.target.value)}>
                                            <option value="<=">&le;</option>
                                            <option value=">=">&ge;</option>
                                            <option value=">">&gt;</option>
                                            <option value="<">&lt;</option>
                                        </select>
                                        <input type="number" className="form-control" style={{ width: '80px', fontWeight: 'bold', border: '1px solid #cbd5e1' }} value={val} onChange={e => setVal(e.target.value)} />
                                        <span style={{ fontSize: '0.95rem', fontWeight: '600', color: '#334155' }}>mois</span>
                                    </div>

                                    <div style={{ display: 'flex', gap: '12px', marginLeft: 'auto' }}>
                                        <button className="btn-action-base btn-reset-global" onClick={handleReset}>Réinitialiser</button>
                                        <button className="btn-action-base btn-exec-global" onClick={handleApply} disabled={loading}>
                                            {loading ? <span className="spinner-border spinner-border-sm me-2"></span> : <i className="fas fa-play me-2"></i>}
                                            Exécuter
                                        </button>
                                    </div>
                                </div>
                            </div>

                            {/* Table Results Premium */}
                            <h5 style={{ fontWeight: '800', color: '#1e293b', marginBottom: '16px', paddingLeft: '8px' }}>Résultats Comparatifs</h5>
                            <div className="table-responsive" style={{ maxHeight: '450px', overflowY: 'auto', borderRadius: '16px', border: '1px solid #e2e8f0', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.05)' }}>
                                <table className="table table-hover mb-0" style={{ fontSize: '0.95rem', textAlign: 'center' }}>
                                    <thead style={{ position: 'sticky', top: 0, zIndex: 5 }}>
                                        <tr>
                                            <th style={{ backgroundColor: '#f8fafc', color: '#475569', fontWeight: 'bold', padding: '16px 12px', borderBottom: '2px solid #cbd5e1' }}>Code Prod.</th>
                                            <th style={{ backgroundColor: '#f8fafc', color: '#475569', fontWeight: 'bold', padding: '16px 12px', borderBottom: '2px solid #cbd5e1', textAlign: 'left' }}>Désignation / Libellé</th>
                                            <th style={{ backgroundColor: '#eef2ff', color: '#4f46e5', fontWeight: 'bold', padding: '16px 12px', borderBottom: '2px solid #cbd5e1' }}>Stock {region1}</th>
                                            <th style={{ backgroundColor: '#eef2ff', color: '#4f46e5', fontWeight: 'bold', padding: '16px 12px', borderBottom: '2px solid #cbd5e1' }}>MM {region1}</th>
                                            <th style={{ backgroundColor: '#eef2ff', color: '#4f46e5', fontWeight: 'bold', padding: '16px 12px', borderBottom: '2px solid #cbd5e1' }}>Rotation {region1}</th>
                                            <th style={{ backgroundColor: '#ecfdf5', color: '#008e54', fontWeight: 'bold', padding: '16px 12px', borderBottom: '2px solid #cbd5e1' }}>Stock {region2}</th>
                                            <th style={{ backgroundColor: '#ecfdf5', color: '#008e54', fontWeight: 'bold', padding: '16px 12px', borderBottom: '2px solid #cbd5e1' }}>MM {region2}</th>
                                            <th style={{ backgroundColor: '#ecfdf5', color: '#008e54', fontWeight: 'bold', padding: '16px 12px', borderBottom: '2px solid #cbd5e1' }}>Rotation {region2}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {results.length === 0 ? (
                                            <tr>
                                                <td colSpan="8" className="text-center py-5">
                                                    <div style={{ padding: '24px', background: '#f8fafc', borderRadius: '12px', display: 'inline-block' }}>
                                                        <i className="fas fa-search text-muted mb-3" style={{ fontSize: '2rem' }}></i>
                                                        <h6 className="text-muted m-0">Aucun produit ne correspond à ces critères d'épuisement.</h6>
                                                    </div>
                                                </td>
                                            </tr>
                                        ) : (
                                            results.map((row, idx) => {
                                                const getBadgeClass = (val) => {
                                                    if (val === 99) return 'bg-success';
                                                    if (val <= 2) return 'bg-danger';
                                                    if (val <= 4) return 'bg-warning text-dark';
                                                    return 'bg-success';
                                                };
                                                return (
                                                <tr key={idx} style={{ backgroundColor: '#ffffff', transition: 'background-color 0.2s', borderBottom: '1px solid #f1f5f9' }}>
                                                    <td style={{ fontWeight: 'bold', color: '#334155', verticalAlign: 'middle' }}>{row.code}</td>
                                                    <td style={{ textAlign: 'left', fontWeight: '500', color: '#1e293b', verticalAlign: 'middle' }}>{row.libelle}</td>
                                                    <td style={{ verticalAlign: 'middle', fontSize: '1.05rem', fontWeight: '600' }}>{row.stock1.toLocaleString()}</td>
                                                    <td style={{ verticalAlign: 'middle', color: '#64748b' }}>{row.mm1.toFixed(1)}</td>
                                                    <td style={{ verticalAlign: 'middle' }}>
                                                        <span className={`badge rounded-pill ${getBadgeClass(row.nbMois1)}`} style={{ padding: '8px 12px', fontSize: '0.9rem', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
                                                            {row.nbMois1 === 99 ? '> 99 mois' : `${row.nbMois1.toFixed(1)} mois`}
                                                        </span>
                                                    </td>
                                                    <td style={{ verticalAlign: 'middle', fontSize: '1.05rem', fontWeight: '600' }}>{row.stock2.toLocaleString()}</td>
                                                    <td style={{ verticalAlign: 'middle', color: '#64748b' }}>{row.mm2.toFixed(1)}</td>
                                                    <td style={{ verticalAlign: 'middle' }}>
                                                        <span className={`badge rounded-pill ${getBadgeClass(row.nbMois2)}`} style={{ padding: '8px 12px', fontSize: '0.9rem', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
                                                            {row.nbMois2 === 99 ? '> 99 mois' : `${row.nbMois2.toFixed(1)} mois`}
                                                        </span>
                                                    </td>
                                                </tr>
                                                );
                                            })
                                        )}
                                    </tbody>
                                </table>
                            </div>

                            {/* Footer actions */}
                            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '16px', marginTop: '24px' }}>
                                <button className="btn-action-base btn-excel-global">
                                    <i className="fas fa-file-excel"></i> Exporter Excel
                                </button>
                                <button 
                                    className="btn-action-base btn-pdf-global"
                                    onClick={() => generateComparisonReport(results, selectedProduct, region1, region2)}
                                    disabled={results.length === 0}
                                >
                                    <i className="fas fa-file-pdf"></i> Exporter PDF
                                </button>
                            </div>
                        </>
                    )}
                </div>
            </div>
        </div>
    );
};

export default CompareRegionsModal;
