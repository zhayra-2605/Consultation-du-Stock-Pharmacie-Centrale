import React, { useEffect, useState } from 'react';
import {
    Chart as ChartJS,
    CategoryScale, LinearScale, BarElement,
    Title, Tooltip, Legend, ArcElement,
    PointElement, LineElement, LineController, BarController,
} from 'chart.js';
import { Chart } from 'react-chartjs-2';
import { api } from '../services/api';

ChartJS.register(
    CategoryScale, LinearScale, BarElement,
    Title, Tooltip, Legend, ArcElement,
    PointElement, LineElement, LineController, BarController
);

// Pie chart color palette per region slot
const PIE_COLORS = ['#009b4d', '#ffc107', '#17a2b8', '#dc3545', '#6c757d', '#28a745', '#20c997', '#6610f2'];

const StatsDashboard = ({ code, isBesoin, sidebarRegions }) => {
    const [stats, setStats] = useState(null);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (!code) return;
        setLoading(true);
        const fetchStats = isBesoin ? api.getStatsByBesoin : api.getStats;
        fetchStats(code)
            .then(res => setStats(res.data))
            .catch(console.error)
            .finally(() => setLoading(false));
    }, [code, isBesoin]);

    if (loading) return <div className="text-center p-3">Chargement des statistiques...</div>;
    if (!stats) return null;

    // Prefer live sidebarRegions over stats.regions for current stock breakdown
    const regionsData = (sidebarRegions?.length > 0)
        ? sidebarRegions
            .filter(r => r.depot !== 'National')
            .map(r => ({ region: r.depot, totalStock: r.totalStock, totalVente: r.totalVente ?? 0 }))
        : (stats.regions ?? []);

    const sortedYears = [...stats.years].sort((a, b) => a.ANNEE - b.ANNEE);
    const latestYear = sortedYears.length > 0 ? sortedYears[sortedYears.length - 1].ANNEE : new Date().getFullYear();
    const displayYears = [...sortedYears].reverse().slice(0, 4);

    // --- Chart data ---
    const pieData = {
        labels: regionsData.map(r => r.region),
        datasets: [{
            data: regionsData.map(r => r.totalStock),
            backgroundColor: PIE_COLORS,
            borderWidth: 1,
        }],
    };

    const comboData = {
        labels: sortedYears.map(y => y.ANNEE),
        datasets: [
            {
                type: 'bar',
                label: 'Stock',
                backgroundColor: '#009b4d',
                data: sortedYears.map(y => Math.round(y.totalStock)),
                borderColor: 'white',
                borderWidth: 2,
                yAxisID: 'y',
            },
            {
                type: 'line',
                label: 'Vente',
                borderColor: '#dc3545',
                borderWidth: 2,
                fill: false,
                data: sortedYears.map(y => Math.round(y.totalVente)),
                tension: 0.4,
                yAxisID: 'y1',
            },
        ],
    };

    const comboOptions = {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                type: 'linear',
                position: 'left',
                title: { display: true, text: 'Stock', color: '#009b4d' },
            },
            y1: {
                type: 'linear',
                position: 'right',
                title: { display: true, text: 'Ventes', color: '#dc3545' },
                grid: { drawOnChartArea: false },
            },
        },
    };

    const cardStyle = { background: 'rgba(255,255,255,0.4)', borderColor: 'rgba(255,255,255,0.5) !important' };

    return (
        <div className="stats-container mt-4 mb-4">
            <div className="row">

                {/* LEFT: Stats cards */}
                <div className="col-md-5">
                    <div className="table-custom-wrapper mb-3">
                        <div className="table-title">📊 Statistiques</div>

                        <h6 className="fw-bold mb-2">Années (Ventes)</h6>
                        <div className="d-flex justify-content-start mb-3 text-center flex-wrap gap-2">
                            {displayYears.map(y => (
                                <div
                                    key={y.ANNEE}
                                    className={`stat-card-mini p-2 border rounded mb-1 ${y.ANNEE === latestYear ? 'bg-success text-white' : ''}`}
                                    style={{ minWidth: '70px', ...(y.ANNEE !== latestYear && cardStyle) }}
                                >
                                    <div className={y.ANNEE === latestYear ? 'small' : 'small text-muted'}>
                                        {y.ANNEE === latestYear ? 'Dernière année' : y.ANNEE}
                                    </div>
                                    <div className="fw-bold">{y.totalVente}</div>
                                </div>
                            ))}
                            {displayYears.length === 0 && <div className="text-muted small">Aucun historique annuel</div>}
                        </div>

                        <h6 className="fw-bold mb-2">Mois (Année {latestYear})</h6>
                        <div className="d-flex justify-content-between mb-3 text-center flex-wrap gap-1">
                            {stats.months.slice(-4).map(m => (
                                <div key={m.MOIS} className="stat-card-mini p-2 border rounded flex-fill" style={cardStyle}>
                                    <div className="small text-muted">
                                        {new Date(0, m.MOIS - 1).toLocaleString('fr-FR', { month: 'long' })}
                                    </div>
                                    <div className="fw-bold text-success">{m.totalVente}</div>
                                </div>
                            ))}
                            {stats.months.length === 0 && <div className="text-muted small w-100">Aucune donnée mensuelle</div>}
                        </div>

                        <h6 className="fw-bold mb-2">Vente par région</h6>
                        <div className="row g-2 mb-3">
                            {regionsData.map(r => (
                                <div key={r.region} className="col-4">
                                    <div className="p-2 border rounded text-center" style={cardStyle}>
                                        <div className="small text-muted text-truncate" title={r.region}>{r.region}</div>
                                        <div className="fw-bold small">{r.totalVente}</div>
                                    </div>
                                </div>
                            ))}
                        </div>

                        <h6 className="fw-bold mb-2">Stock par région</h6>
                        <div className="row g-2">
                            {regionsData.map(r => (
                                <div key={r.region} className="col-4">
                                    <div className="p-2 border rounded text-center" style={{ borderLeft: '3px solid #009b4d', background: 'rgba(255,255,255,0.4)' }}>
                                        <div className="small text-muted text-truncate" title={r.region}>{r.region}</div>
                                        <div className="fw-bold small text-success">{r.totalStock}</div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* RIGHT: Charts */}
                <div className="col-md-7">
                    <div className="table-custom-wrapper h-100 d-flex flex-column">
                        <div className="table-title">📉 Graphiques &amp; Analyses</div>
                        <div className="d-flex flex-column justify-content-around flex-grow-1">
                            <div className="chart-container mb-4" style={{ height: '250px', position: 'relative' }}>
                                <h6 className="text-center text-muted mb-2">Stock par Région</h6>
                                <Chart type="pie" data={pieData} options={{ maintainAspectRatio: false }} />
                            </div>
                            <hr />
                            <div className="chart-container" style={{ height: '250px', position: 'relative' }}>
                                <h6 className="text-center text-muted mb-2">Stock &amp; Vente par Année</h6>
                                <Chart type="bar" data={comboData} options={comboOptions} />
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    );
};

export default StatsDashboard;
