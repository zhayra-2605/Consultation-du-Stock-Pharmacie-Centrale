import React, { useState } from 'react';

const CriticalNeedsList = ({ hubId, hubName, onHubChange }) => {
  const [period, setPeriod] = useState(3); // 3, 6, 12 mois

  const hubs = [
    { id: 'TUNIS', name: 'Tunis' },
    { id: 'KEF', name: 'El Kef' },
    { id: 'SOUSSE', name: 'Sousse' },
    { id: 'GAFSA', name: 'Gafsa' },
    { id: 'SFAX', name: 'Sfax' },
    { id: 'MEDENINE', name: 'Médenine' },
  ];

  // Mock data adjusted by period
  const getMockNeeds = () => {
    const base = [
      { code: '2-0501', label: 'Antibiotiques', coverage: 12, trend: 'down', color: 'var(--danger-red)' },
      { code: '1-1200', label: 'Cardiologie', coverage: 28, trend: 'up', color: '#f59e0b' },
      { code: '3-0450', label: 'Diabète', coverage: 35, trend: 'stable', color: '#f59e0b' },
      { code: '4-0100', label: 'Oncologie', coverage: 18, trend: 'down', color: 'var(--danger-red)' },
      { code: '1-0850', label: 'Analgésiques', coverage: 65, trend: 'up', color: 'var(--bio-green-primary)' },
      { code: '5-0200', label: 'Gynécologie', coverage: 22, trend: 'down', color: '#f59e0b' },
      { code: '2-0900', label: 'Vaccins', coverage: 44, trend: 'up', color: 'var(--bio-green-primary)' },
      { code: '1-1500', label: 'Dermatologie', coverage: 39, trend: 'down', color: '#f59e0b' },
      { code: '4-0550', label: 'Ophtalmologie', coverage: 15, trend: 'down', color: 'var(--danger-red)' },
      { code: '3-0660', label: 'Psychiatrie', coverage: 51, trend: 'stable', color: 'var(--bio-green-primary)' },
    ];
    
    // Simulate worse outcomes for longer periods
    return base.map(n => ({
        ...n,
        coverage: Math.max(5, n.coverage - (period === 12 ? 15 : (period === 6 ? 7 : 0))),
        color: (n.coverage - (period === 12 ? 15 : (period === 6 ? 7 : 0))) < 20 ? 'var(--danger-red)' : '#f59e0b'
    }));
  };

  const mockNeeds = getMockNeeds();

  return (
    <div className="needs-card">
      <div className="needs-header">
        <h3 className="section-title">Top 10 Besoins Critiques</h3>
        <p className="section-subtitle">Hub actuel : {hubName || 'National'}</p>
        
        {/* Barre de Contrôle des Filtres */}
        <div className="control-bar">
          <div className="control-group">
             <label>Région :</label>
             <select 
               value={hubId || ''} 
               onChange={(e) => onHubChange(e.target.value)}
               className="glass-select"
             >
               <option value="">National (Global)</option>
               {hubs.map(h => <option key={h.id} value={h.id}>{h.name}</option>)}
             </select>
          </div>
          
          <div className="control-group">
             <label>Prévision :</label>
             <div className="period-tabs">
                {[3, 6, 12].map(m => (
                  <button 
                    key={m} 
                    className={`period-btn ${period === m ? 'active' : ''}`}
                    onClick={() => setPeriod(m)}
                  >
                    {m}m
                  </button>
                ))}
             </div>
          </div>
        </div>
      </div>

      <div className="needs-list">
        {mockNeeds.map((need, idx) => (
          <div key={need.code} className="need-item">
            <div className="need-info">
              <span className="need-rank">{idx + 1}.</span>
              <div className="need-details">
                <span className="need-label">{need.label}</span>
                <span className="need-code">{need.code}</span>
              </div>
              <div className="need-stats">
                <span className="stat-value" style={{ color: need.color }}>{need.coverage}%</span>
                <span className="stat-label">Couverture</span>
              </div>
            </div>
            
            <div className="need-progress-container">
              <div className="need-progress-bg">
                <div 
                  className="need-progress-bar" 
                  style={{ width: `${need.coverage}%`, backgroundColor: need.color }} 
                />
              </div>
              {need.coverage < 20 && (
                <div className="alert-badge">⚠️ Rupture sous 10j</div>
              )}
            </div>
          </div>
        ))}
      </div>

      <style jsx>{`
        .needs-card {
          flex: 1;
          background: var(--glass-white);
          backdrop-filter: blur(24px);
          border-radius: var(--radius-glass-card);
          padding: 24px;
          border: 1px solid var(--glass-border);
          box-shadow: var(--shadow-glass);
          max-height: 800px;
          overflow-y: auto;
          scrollbar-width: thin;
        }

        .section-title { font-weight: 800; font-size: 1.1rem; margin: 0; }
        .section-subtitle { font-size: 0.85rem; color: var(--bio-green-primary); font-weight: 700; margin: 4px 0 16px 0; }

        .control-bar {
          display: flex;
          flex-direction: column;
          gap: 12px;
          margin-bottom: 20px;
          padding-bottom: 16px;
          border-bottom: 1px solid rgba(0,0,0,0.05);
        }
        .control-group {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 10px;
        }
        .control-group label {
          font-size: 0.75rem;
          font-weight: 800;
          color: var(--text-muted);
          text-transform: uppercase;
        }
        
        .glass-select {
          background: rgba(255,255,255,0.5);
          border: 1px solid var(--glass-border);
          border-radius: 8px;
          padding: 6px 12px;
          font-size: 0.85rem;
          font-weight: 700;
          color: var(--text-primary);
          outline: none;
          max-width: 140px;
        }

        .period-tabs {
          display: flex;
          background: rgba(0,0,0,0.05);
          border-radius: 10px;
          padding: 2px;
        }
        .period-btn {
          border: none;
          background: none;
          padding: 4px 10px;
          font-size: 0.75rem;
          font-weight: 800;
          color: var(--text-muted);
          cursor: pointer;
          border-radius: 8px;
          transition: all 0.3s;
        }
        .period-btn.active {
          background: white;
          color: var(--bio-green-primary);
          box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        .needs-list { display: flex; flex-direction: column; gap: 12px; }

        .need-item {
          background: rgba(255, 255, 255, 0.4);
          border: 1px solid rgba(255, 255, 255, 0.6);
          border-radius: 12px;
          padding: 12px;
          transition: var(--transition-fluid);
        }
        .need-item:hover { background: white; transform: scale(1.02); }

        .need-info { display: flex; align-items: center; gap: 12px; margin-bottom: 8px; }
        .need-rank { font-weight: 900; color: var(--text-muted); width: 24px; }
        .need-details { flex: 1; display: flex; flex-direction: column; }
        .need-label { font-weight: 800; font-size: 0.95rem; color: var(--text-primary); }
        .need-code { font-size: 0.75rem; color: var(--text-muted); font-family: monospace; }

        .need-stats { text-align: right; }
        .stat-value { font-weight: 900; font-size: 1.1rem; }
        .stat-label { font-size: 0.65rem; text-transform: uppercase; color: var(--text-muted); display: block; }

        .need-progress-container { display: flex; align-items: center; gap: 12px; }
        .need-progress-bg { flex: 1; height: 6px; background: rgba(0,0,0,0.05); border-radius: 3px; overflow: hidden; }
        .need-progress-bar { height: 100%; border-radius: 3px; }
        
        .alert-badge {
          font-size: 0.65rem;
          font-weight: 800;
          color: var(--danger-red);
          background: rgba(225, 29, 72, 0.1);
          padding: 2px 6px;
          border-radius: 4px;
        }
      `}</style>
    </div>
  );
};

export default CriticalNeedsList;
