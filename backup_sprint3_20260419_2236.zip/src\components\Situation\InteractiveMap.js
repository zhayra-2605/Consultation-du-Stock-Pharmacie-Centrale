import React, { useState } from 'react';
import { TUNISIA_REGIONS } from '../../assets/tunisia_paths';

const TunisiaMap = ({ selectedHub, onHubClick }) => {
  const [hoveredHub, setHoveredHub] = useState(null);
  const [hoveredGov, setHoveredGov] = useState(null);

  const handleHubClick = (hubId) => {
    onHubClick(hubId === selectedHub ? null : hubId);
  };

  return (
    <div className="map-card">
      <div className="map-header">
        <h3 className="section-title">🗺️ Précision Géographique Officielle</h3>
        <p className="section-subtitle">Réseau PHCT — 24 Gouvernorats · 6 Hubs Stratégiques</p>
      </div>

      <div className="map-body">

        {/* SVG Map — prend toute la hauteur */}
        <div className="map-svg-wrapper">
          <svg viewBox="0 225 230 410" className="tunisia-svg" preserveAspectRatio="xMidYMid meet">
            {TUNISIA_REGIONS.map((hub) => (
              <g
                key={hub.hub}
                className={`hub-group ${selectedHub === hub.hub ? 'active' : ''}`}
                onClick={() => handleHubClick(hub.hub)}
                onMouseEnter={() => setHoveredHub(hub.hub)}
                onMouseLeave={() => { setHoveredHub(null); setHoveredGov(null); }}
              >
                {hub.governorates.map((gov) => (
                  <path
                    key={gov.id}
                    d={gov.path}
                    className="gov-path"
                    fill={selectedHub === hub.hub ? hub.color : (hoveredHub === hub.hub ? hub.color : hub.color)}
                    style={{
                      opacity: selectedHub && selectedHub !== hub.hub ? 0.35 : (hoveredHub === hub.hub ? 0.95 : 0.72),
                    }}
                    onMouseEnter={() => setHoveredGov(gov.name)}
                  >
                    <title>{gov.name} · {hub.name}</title>
                  </path>
                ))}
              </g>
            ))}
          </svg>

          {/* Tooltip au survol gouvernorat */}
          {hoveredGov && (
            <div className="gov-tooltip">{hoveredGov}</div>
          )}
        </div>

        {/* Légende verticale à droite */}
        <div className="map-legend">
          {TUNISIA_REGIONS.map((hub) => (
            <div
              key={hub.hub}
              className={`legend-item ${selectedHub === hub.hub ? 'legend-active' : ''}`}
              onClick={() => handleHubClick(hub.hub)}
              onMouseEnter={() => setHoveredHub(hub.hub)}
              onMouseLeave={() => setHoveredHub(null)}
            >
              <div className="legend-dot" style={{ background: hub.color }} />
              <div className="legend-info">
                <strong>{hub.name}</strong>
                <span>{hub.surface}</span>
                {(hoveredHub === hub.hub || selectedHub === hub.hub) && (
                  <div className="legend-govs">
                    {hub.governorates.map(g => (
                      <span key={g.id} className={hoveredGov === g.name ? 'gov-active' : ''}>
                        {g.name}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      <style jsx>{`
        .map-card {
          flex: 1.8;
          background: var(--glass-white);
          backdrop-filter: blur(24px);
          border-radius: var(--radius-glass-card);
          padding: 20px 24px;
          border: 1px solid var(--glass-border);
          box-shadow: var(--shadow-glass);
          display: flex;
          flex-direction: column;
          min-height: 720px;
        }

        .map-header { margin-bottom: 16px; }
        .section-title { font-weight: 800; font-size: 1.15rem; margin: 0; color: var(--text-primary); }
        .section-subtitle { font-size: 0.85rem; color: var(--text-muted); margin: 4px 0 0 0; }

        /* Layout principal : carte + légende côte à côte */
        .map-body {
          flex: 1;
          display: flex;
          gap: 16px;
          min-height: 0;
        }

        /* Wrapper SVG — tout l'espace restant */
        .map-svg-wrapper {
          flex: 1;
          position: relative;
          display: flex;
          align-items: stretch;
        }

        .tunisia-svg {
          width: 100%;
          height: 100%;
          min-height: 550px;
          filter: drop-shadow(0 8px 24px rgba(0,0,0,0.12));
          transition: all 0.4s ease;
        }

        .hub-group {
          cursor: pointer;
          transition: all 0.3s ease;
        }

        .gov-path {
          stroke: white;
          stroke-width: 0.6;
          transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        }

        .hub-group:hover .gov-path {
          stroke-width: 1.2;
          filter: brightness(1.15) saturate(1.2);
        }

        .hub-group.active .gov-path {
          stroke: white;
          stroke-width: 1.8;
          filter: drop-shadow(0 0 10px currentColor) brightness(1.1);
        }

        /* Tooltip petit gouvernorat */
        .gov-tooltip {
          position: absolute;
          bottom: 12px;
          left: 50%;
          transform: translateX(-50%);
          background: rgba(15,20,40,0.85);
          color: white;
          padding: 6px 14px;
          border-radius: 20px;
          font-size: 0.8rem;
          font-weight: 600;
          pointer-events: none;
          white-space: nowrap;
          backdrop-filter: blur(8px);
          box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        }

        /* Légende verticale */
        .map-legend {
          width: 158px;
          flex-shrink: 0;
          display: flex;
          flex-direction: column;
          gap: 6px;
          overflow-y: auto;
          padding: 4px 0;
        }

        .map-legend::-webkit-scrollbar { width: 3px; }
        .map-legend::-webkit-scrollbar-thumb { background: var(--glass-border); border-radius: 4px; }

        .legend-item {
          display: flex;
          align-items: flex-start;
          gap: 10px;
          padding: 10px 12px;
          border-radius: 12px;
          border: 1.5px solid transparent;
          cursor: pointer;
          transition: all 0.25s ease;
          background: rgba(255,255,255,0.5);
        }

        .legend-item:hover {
          background: white;
          border-color: var(--glass-border);
          box-shadow: 0 4px 14px rgba(0,0,0,0.07);
          transform: translateX(-2px);
        }

        .legend-active {
          background: white !important;
          border-color: var(--bio-green-primary) !important;
          box-shadow: 0 0 18px rgba(0, 168, 89, 0.15) !important;
        }

        .legend-dot {
          width: 12px;
          height: 12px;
          border-radius: 50%;
          flex-shrink: 0;
          margin-top: 3px;
          box-shadow: 0 2px 6px rgba(0,0,0,0.2);
        }

        .legend-info {
          display: flex;
          flex-direction: column;
          gap: 2px;
          min-width: 0;
        }

        .legend-info strong {
          font-size: 0.78rem;
          font-weight: 700;
          color: var(--text-primary);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        .legend-info > span {
          font-size: 0.7rem;
          color: var(--text-muted);
        }

        .legend-govs {
          margin-top: 6px;
          display: flex;
          flex-direction: column;
          gap: 2px;
          border-top: 1px solid rgba(0,0,0,0.06);
          padding-top: 6px;
        }

        .legend-govs span {
          font-size: 0.68rem;
          color: var(--text-muted);
          padding: 1px 0;
        }

        .gov-active {
          color: var(--bio-green-primary) !important;
          font-weight: 700 !important;
        }
      `}</style>
    </div>
  );
};

export default TunisiaMap;
