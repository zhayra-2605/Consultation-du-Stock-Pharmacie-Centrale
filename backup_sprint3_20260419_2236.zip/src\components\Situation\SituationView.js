import React, { useState } from 'react';
import MetricGauges from './MetricGauges';
import InteractiveMap from './InteractiveMap';
import CriticalNeedsList from './CriticalNeedsList';

const SituationView = ({ onBack }) => {
  const [selectedHub, setSelectedHub] = useState(null);
  
  const getHubName = (id) => {
    const names = {
      'TUNIS': 'Tunis',
      'KEF': 'El Kef',
      'SOUSSE': 'Sousse',
      'GAFSA': 'Gafsa',
      'SFAX': 'Sfax',
      'MEDENINE': 'Médenine'
    };
    return names[id] || 'National';
  };

  return (
    <div className="situation-fade-container">
      <div className="situation-header">
        <button className="back-btn" onClick={onBack}>
          <span>⬅</span> Retour à la Recherche
        </button>
        <div className="view-title">
          <h2>Tableau de Bord Situation & Alertes (IA)</h2>
          <p>Analyse prédictive de la chaîne de distribution PHCT</p>
        </div>
      </div>

      <MetricGauges />

      <div className="situation-main-grid">
        <InteractiveMap 
          selectedHub={selectedHub} 
          onHubClick={(id) => setSelectedHub(id === selectedHub ? null : id)} 
        />
        
        <CriticalNeedsList 
          hubId={selectedHub} 
          hubName={getHubName(selectedHub)} 
          onHubChange={(id) => setSelectedHub(id || null)}
        />
      </div>

      <style jsx>{`
        .situation-fade-container {
          animation: fadeIn 0.8s ease-out forwards;
          display: flex;
          flex-direction: column;
          gap: 20px;
          padding: 10px 0;
        }

        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }

        .situation-header {
          display: flex;
          align-items: center;
          gap: 24px;
          margin-bottom: 24px;
          padding: 0 10px;
        }

        .back-btn {
          background: var(--glass-white);
          border: 1px solid var(--glass-border);
          border-radius: var(--radius-pill);
          padding: 10px 24px;
          font-weight: 800;
          color: var(--bio-green-primary);
          cursor: pointer;
          transition: var(--transition-fluid);
          box-shadow: var(--shadow-glass);
          display: flex;
          align-items: center;
          gap: 12px;
        }
        .back-btn:hover { background: white; transform: translateX(-5px); box-shadow: 0 8px 20px rgba(0,0,0,0.1); }
        .back-btn span { font-size: 1.2rem; }

        .view-title h2 { margin: 0; font-weight: 850; font-size: 1.7rem; color: var(--text-primary); }
        .view-title p { margin: 4px 0 0 0; color: var(--text-muted); font-size: 0.95rem; font-weight: 600; }

        .situation-main-grid {
          display: flex;
          gap: 24px;
          align-items: flex-start;
        }

        @media (max-width: 1200px) {
          .situation-main-grid { flex-direction: column; }
        }
      `}</style>
    </div>
  );
};

export default SituationView;
