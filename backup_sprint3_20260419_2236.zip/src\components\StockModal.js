import React from 'react';
import { Modal, Table } from 'react-bootstrap';

// Récupère la date de péremption (plusieurs noms possibles selon l'API)
const getDatePeremption = (item) => {
    const date = item.DATEPEREMP ?? item.date_peremption ?? item.DATE_PEREMPTION ?? '';
    if (!date || date === '0000-00-00' || String(date).startsWith('0000-00-00')) {
        return '-';
    }
    return date;
};

const StockModal = ({ show, onHide, depotName, stockDetails }) => {
    return (
        <Modal show={show} onHide={onHide} size="xl" centered>
            <Modal.Header closeButton className="bg-success text-white">
                <Modal.Title>Stock Dépôt {depotName && `- ${depotName}`}</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <div className="table-responsive">
                    <Table striped bordered hover>
                        <thead>
                            <tr style={{ backgroundColor: '#d1e7dd', color: '#0f5132' }}>
                                <th>Code Produit</th>
                                <th>Libellé</th>
                                <th>Dépôt</th>
                                <th>Num lot</th>
                                <th>Date péremption</th>
                                <th>Stock</th>
                                <th>Qte bloquée</th>
                                <th>Quarantaine</th>
                                <th>Stock total</th>
                                <th>Vente total</th>
                            </tr>
                        </thead>
                        <tbody>
                            {stockDetails && stockDetails.map((item, index) => (
                                <tr key={index}>
                                    <td>{item.CODE_PRODUIT}</td>
                                    <td>{item.LIBELLE}</td>
                                    <td>{item.LIBELLE_DEPOT}</td>
                                    <td>{item.NUMLOT}</td>
                                    <td>{getDatePeremption(item)}</td>
                                    <td>{item.QUANTITET}</td>
                                    <td>{item.QTEBLK}</td>
                                    <td>{item.QUARANTAINE}</td>
                                    <td>{item.STOCK_TOTAL}</td>
                                    <td>{item.VENTE_TOTAL}</td>
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                </div>
            </Modal.Body>
        </Modal>
    );
};

export default StockModal;
