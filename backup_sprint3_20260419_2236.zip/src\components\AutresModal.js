import React from 'react';
import '../styles/index.css';
import { getCodeBesoin, getCodeProduit, getLibelleBesoin, getLibelleProduit, getPresentation } from '../utils/dataUtils';

const AutresModal = ({ isOpen, onClose, product, relatedProducts }) => {
    if (!isOpen) return null;

    // Use the related products provided (from DetailsTable data) or fallback to an empty array
    const products = relatedProducts && relatedProducts.length > 0 ? relatedProducts : [];

    return (
        <div className="modal-overlay" onClick={onClose} style={{ zIndex: 1060 }}>
            <div className="modal-content-custom modal-autres" onClick={(e) => e.stopPropagation()} style={{ width: '1000px', maxWidth: '98%' }}>
                
                {/* Header - Green */}
                <div className="modal-header-custom" style={{ backgroundColor: '#008e54', padding: '24px 32px', borderBottom: 'none', borderRadius: '24px 24px 0 0' }}>
                    <h4 style={{ color: 'white', margin: 0, fontSize: '1.4rem', fontWeight: 'bold', display: 'flex', alignItems: 'center' }}>
                        Autres – MM3 MM6 MM12
                    </h4>
                    <button className="btn-close-custom" onClick={onClose} aria-label="Fermer">×</button>
                </div>

                <div className="modal-body-custom" style={{ padding: '24px', backgroundColor: '#ffffff', overflowY: 'auto' }}>
                    
                    {/* Informations du ticket */}
                    <div style={{ marginBottom: '24px' }}>
                        <h5 style={{ color: '#6b7280', fontWeight: 'bold', fontSize: '1rem', marginBottom: '8px' }}>
                            Informations du ticket
                        </h5>
                        <div style={{ border: '1px solid #e5e7eb', borderRadius: '8px', padding: '16px', backgroundColor: '#f9fafb', fontFamily: 'monospace', fontSize: '13px', color: '#374151' }}>
                            <div>Libellé Besoin : {getLibelleBesoin(product) || 'N/A'}</div>
                            <div>Présentation : {getPresentation(product) || 'N/A'}</div>
                            <div>Code Besoin : {getCodeBesoin(product) || 'N/A'}</div>
                        </div>
                    </div>

                    {/* Table */}
                    <div className="table-responsive" style={{ border: '1px solid #dee2e6', borderRadius: '8px', marginBottom: '24px' }}>
                        <table className="table table-bordered mb-0" style={{ fontSize: '0.9rem', textAlign: 'center' }}>
                            <thead style={{ backgroundColor: '#e5e7eb' }}>
                                <tr>
                                    <th style={{ backgroundColor: '#e5e7eb', padding: '10px 12px', borderBottom: '1px solid #dee2e6', color: '#111827', fontWeight: 'bold' }}>Code</th>
                                    <th style={{ backgroundColor: '#e5e7eb', padding: '10px 12px', borderBottom: '1px solid #dee2e6', color: '#111827', fontWeight: 'bold' }}>Libellé</th>
                                    <th style={{ backgroundColor: '#e5e7eb', padding: '10px 12px', borderBottom: '1px solid #dee2e6', color: '#111827', fontWeight: 'bold' }}>Prés</th>
                                    <th style={{ backgroundColor: '#e5e7eb', padding: '10px 12px', borderBottom: '1px solid #dee2e6', color: '#111827', fontWeight: 'bold' }}>1ère facture</th>
                                    <th style={{ backgroundColor: '#e5e7eb', padding: '10px 12px', borderBottom: '1px solid #dee2e6', color: '#111827', fontWeight: 'bold' }}>MM12</th>
                                    <th style={{ backgroundColor: '#e5e7eb', padding: '10px 12px', borderBottom: '1px solid #dee2e6', color: '#111827', fontWeight: 'bold' }}>MM6</th>
                                    <th style={{ backgroundColor: '#e5e7eb', padding: '10px 12px', borderBottom: '1px solid #dee2e6', color: '#111827', fontWeight: 'bold' }}>MM3</th>
                                </tr>
                            </thead>
                            <tbody>
                                {products.length > 0 ? products.map((prod, idx) => {
                                    return (
                                        <tr key={idx} style={{ backgroundColor: '#ffffff' }}>
                                            <td style={{ padding: '10px 12px' }}>{getCodeProduit(prod) || '-'}</td>
                                            <td style={{ padding: '10px 12px', textAlign: 'left' }}>{getLibelleProduit(prod) || '-'}</td>
                                            <td style={{ padding: '10px 12px' }}>{getPresentation(prod) || '-'}</td>
                                            <td style={{ padding: '10px 12px' }}>{prod?.PREMIERE_FACTURE || '-'}</td>
                                            <td style={{ padding: '10px 12px' }}>{prod?.MM12 != null ? prod.MM12.toFixed(2) : '-'}</td>
                                            <td style={{ padding: '10px 12px' }}>{prod?.MM6 != null ? prod.MM6.toFixed(2) : '-'}</td>
                                            <td style={{ padding: '10px 12px' }}>{prod?.MM3 != null ? prod.MM3.toFixed(2) : '-'}</td>
                                        </tr>
                                    );
                                }) : (
                                    <tr>
                                        <td colSpan="7" className="text-center py-3 text-muted" style={{ backgroundColor: '#ffffff' }}>
                                            Aucun produit lié
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>

                    {/* Action Buttons */}
                    <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '16px' }}>
                        <button className="btn-action-base btn-excel-global">
                            <i className="fas fa-file-excel"></i> Exporter Excel
                        </button>
                        <button className="btn-action-base btn-pdf-global">
                            <i className="fas fa-file-pdf"></i> Exporter PDF
                        </button>
                    </div>

                </div>
            </div>
        </div>
    );
};

export default AutresModal;
